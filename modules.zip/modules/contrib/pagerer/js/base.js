/**
 * @file
 * Pagerer jquery scripts.
 *
 * All jQuery navigation widgets implemented by pagerer are configured at
 * runtime by a JSON object prepared by the PHP part of the module, and
 * stored in a 'pagererState' object attached to each widget.
 *
 * pagererState properties:
 * - url: the URL of the target page for navigation
 * - queryString: the query string fragment of the request
 * - element: integer to distinguish between multiple pagers on one page
 * - quantity: number of page elements in the pager list
 * - total: total number of pages in the query
 * - totalItems: total number of items in the query
 * - current: 0-base index of current page
 * - interval: number of elements per page (1 if display = pages, items per
 *   page if display = items/item_ranges)
 * - display: pages|items|item_ranges indicates what is displayed in the page
 *   element
 * - pageSeparator: Text to fill between contiguous pages.
 * - pageTag: Array of text elements to use to render page/item/item range.
 * - widgetResize: (widget) determines if the widget width should be calculated
 *   dynamically based on the width of the string of the last page/item number.
 * - sliderWidth: (slider) determines the width of the slider bar in 'em's.
 *   If not set, CSS styling will prevail.
 * - action: (slider) determines how the page relocation should be triggered
 *   after it has been selected through the jQuery slider.
 * - timeout: (slider) the grace time (in milliseconds) to wait before the
 *   page is relocated, in case "timeout" action method is selected for
 *   the jQuery slider.
 * - icons: (slider) determines whether to display +/- navigation icons
 *   on the sides of the jQuery slider.
 * - tickmarkTitle: (slider) help text appended to the slider help when user is
 *   expected to click on the tickmark to start page relocation.
 */

(function ($) {

  'use strict';

  /**
   * Pagerer base utility functions.
   */
  Drupal.pagerer = Drupal.pagerer || {

    /**
     * State variables.
     *
     * These variables are reset at every page load, either normal or AJAX.
     */
    state: {
      timeoutAction: 0,
      intervalAction: 0,
      intervalCount: 0,
      isRelocating: false
    },

    /**
     * Return page text from zero-based page index number.
     *
     * @param {number} index
     *   The page number (0-indexed) to navigate to.
     * @param {object} pState
     *   A Pagerer state object.
     * @param {string} tagType
     *   The text to be formatted, page or title.
     *
     * @return {number}
     *   A formatted and translated text string to be used for rendering a
     *   pager element.
     */
    indexToTag: function (index, pState, tagType) {

      index = parseInt(index);
      var offset = index - pState.current;

      // Get required tag.
      var tag;
      if (tagType === 'page') {
        if (offset === 0) {
          tag = pState.pageTag.page_current;
        }
        else {
          if (offset < 0) {
            tag = pState.pageTag.page_previous;
          }
          else {
            tag = pState.pageTag.page_next;
          }
        }
      }
      else {
        if (index === 0) {
          tag = pState.pageTag.first_title;
        }
        else if (index === (pState.total - 1)) {
          tag = pState.pageTag.last_title;
        }
        else {
          tag = pState.pageTag.page_title;
        }
      }

      // Items.
      var l_item = (index * pState.interval) + 1;
      var h_item = Math.min(((index + 1) * pState.interval), pState.totalItems);
      var item_offset = offset * pState.interval;

      // Pages.
      var num = index + 1;
      var t_offset = offset;

      // Format text string.
      return Drupal.formatString(tag, {
        '@number': num,
        '@offset': t_offset,
        '@item_offset': item_offset,
        '@item_low': l_item,
        '@item_high': h_item,
        '@item': l_item,
        '@total_items': pState.totalItems,
        '@total': pState.total
      });
    },

    /**
     * Return zero-based page index number from textual value.
     *
     * @param {number} value
     *   A number, either a page or an item (1-indexed).
     * @param {HTMLElement} element
     *   An HTML element.
     *
     * @return {number}
     *   The page number (0-indexed) the link will navigate to.
     */
    valueToIndex: function (value, element) {
      var elementState = element.pagererState;
      switch (elementState.display) {
        case 'pages':
          if (isNaN(value)) {
            return 0;
          }
          value = parseInt(value);
          if (value < 1) {
            return 0;
          }
          if (value > elementState.total) {
            value = elementState.total;
          }
          return value - 1;

        case 'items':
          if (isNaN(value)) {
            return 0;
          }
          value = parseInt(value);
          if (value < 1) {
            return 0;
          }
          if (value > elementState.totalItems) {
            value = elementState.totalItems;
          }
          return parseInt((value - 1) / elementState.interval);

      }
    },

    /**
     * Return an element's pagererState from the HTML attribute.
     *
     * @param {HTMLElement} element
     *   An HTML element.
     *
     * @return {object}
     *   A Pagerer state object.
     */
    evalState: function (element) {
      var pagererStateId = $(element).attr('id');
      var pagererState = drupalSettings.pagerer.state[pagererStateId];
      var ajaxViewId = this.getAjaxViewId(element);

      if (ajaxViewId) {
        // Element is in Views AJAX context.
        pagererState.context = 'viewsAjax';
        pagererState.ajaxViewId = ajaxViewId;

      }
      else if (this.getViewsPreviewContext(element)) {
        // Element is in Views preview context.
        pagererState.context = 'viewsPreview';

      }
      else {
        // Normal page.
        pagererState.context = 'document';

      }

      return pagererState;
    },

    /**
     * Clears an element's pagererState from drupalSettings.
     *
     * @param {HTMLElement} element
     *   An HTML element.
     */
    detachState: function (element) {
      var pagererStateId = $(element).attr('id');
      delete drupalSettings.pagerer.state[pagererStateId];
      return;
    },

    /**
     * Return zero-based page index number from element href.
     *
     * @param {HTMLElement} element
     *   An HTML anchor element.
     * @param {object} pState
     *   A Pagerer state object.
     *
     * @return {number}
     *   The page number (0-indexed) the link will navigate to.
     */
    elementToIndex: function (element, pState) {
      var url = $(element).find('a').attr('href');
      if (typeof url == 'undefined') {
        if ($(element).hasClass('pager-current')) {
          return pState.current;
        }
        return 0;
      }
      var queryParameters = this.parseQueryString(url);
      if (typeof queryParameters['page'] == 'undefined') {
        return 0;
      }
      var elementPages = queryParameters['page'].split(',');
      if (typeof elementPages[pState.element] == 'undefined') {
        return 0;
      }
      return parseInt(elementPages[pState.element]);
    },

    /**
     * Helper function to parse a querystring.
     *
     * Copy of Drupal.Views.parseQueryString since the Views module may not be
     * enabled.
     *
     * @param {string} query
     *   The querystring to parse.
     *
     * @return {object}
     *   A map of query parameters.
     */
    parseQueryString: function (query) {
      var args = {};
      var pos = query.indexOf('?');
      if (pos !== -1) {
        query = query.substring(pos + 1);
      }
      var pair;
      var pairs = query.split('&');
      for (var i = 0; i < pairs.length; i++) {
        pair = pairs[i].split('=');
        // Ignore the 'q' path argument, if present.
        if (pair[0] !== 'q' && pair[1]) {
          args[decodeURIComponent(pair[0].replace(/\+/g, ' '))] = decodeURIComponent(pair[1].replace(/\+/g, ' '));
        }
      }
      return args;
    },

    /**
     * Reset pending transitions.
     *
     * Cancel timeout-bound page relocation and any unprocessed scrollpane
     * transition.
     */
    reset: function () {
      if (this.state.timeoutAction) {
        clearTimeout(this.state.timeoutAction);
      }
    },

    /**
     * Gets the URL to be used for links/AJAX relocation.
     *
     * @param {object} pState
     *   The Pagerer state associated with an element.
     * @param {number} targetPage
     *   The page to relocate to.
     * @param {boolean} queryOnNullUrl
     *   If TRUE, indicates to return the Pagerer state URL also if it is NULL.
     *
     * @return {string}
     *   The URL to be used for relocation.
     */
    getTargetUrl: function (pState, targetPage, queryOnNullUrl) {
      var targetUrl;
      if (pState.url || (!pState.url && queryOnNullUrl)) {
        targetUrl = pState.url;
      }
      else {
        targetUrl = Drupal.url(location.pathname.slice(drupalSettings.path.baseUrl.length + drupalSettings.path.pathPrefix.length));
      }
      if (pState.queryString) {
        targetUrl = targetUrl + '?' + pState.queryString.replace(/pagererpage/, targetPage);
      }
      return targetUrl;
    },

    /**
     * Relocate client browser to target page.
     *
     * Relocation method is decided based on the context of the pager element:
     *  - a normal page - document.location is used.
     *  - a Views preview area in a Views settings form - AJAX is used.
     *  - a AJAX enabled Views context - AJAX is used.
     *
     * @param {HTMLElement} element
     *   The element triggering the relocation.
     * @param {number} targetPage
     *   The page to relocate to.
     *
     * @return {boolean}
     *   FALSE if already relocating.
     */
    relocate: function (element, targetPage) {
      // Check we are not relocating already.
      if (this.state.isRelocating) {
        return false;
      }
      this.state.isRelocating = true;

      var targetUrl = this.getTargetUrl(element.pagererState, targetPage, false);

      if (element.pagererState.context === 'document') {
        // Normal page.
        document.location = targetUrl;

      }
      else if (element.pagererState.context === 'viewsPreview') {
        // Element is in Views preview context.
        var previewRelocate = this.setAjaxViewPreviewPaging(null, null, targetUrl);
        previewRelocate.execute();

      }
      else if (element.pagererState.context === 'viewsAjax') {
        // Element is in Views AJAX context.
        var ajaxViewRelocate = this.setAjaxViewPaging(null, null, element.pagererState.ajaxViewId, targetUrl);
        ajaxViewRelocate.execute();

      }
    },

    /**
     * Views - Return parent Ajax view ID.
     *
     * @param {HTMLElement} element
     *   The element for which to find the Ajax view ID.
     *
     * @return {string|boolean}
     *   The Ajax view ID if found, FALSE otherwise.
     */
    getAjaxViewId: function (element) {
      if (drupalSettings && drupalSettings.views && drupalSettings.views.ajaxViews) {
        // Loop through active Views Ajax elements.
        var ajaxViews = drupalSettings.views.ajaxViews;
        for (var i in ajaxViews) {
          if (ajaxViews.hasOwnProperty(i)) {
            var view = '.js-view-dom-id-' + drupalSettings.views.ajaxViews[i].view_dom_id;
            var viewDiv = $(element).parents(view);
            if (viewDiv.length) {
              return i;
            }
          }
        }
      }
      return false;
    },

    /**
     * Views - Set Views AJAX paging.
     *
     * @param {HTMLElement} element
     *   The element to associate the AJAX behaviour with.
     * @param {event} event
     *   The event that will trigger the AJAX behaviour.
     * @param {string} ajaxViewId
     *   The AJAX id of the view.
     * @param {string} href
     *   The URL to invoke.
     *
     * @return {Drupal.Ajax}
     *   A Drupal.Ajax object.
     */
    setAjaxViewPaging: function (element, event, ajaxViewId, href) {
      var ajaxView = Drupal.views.instances[ajaxViewId];
      var viewData = {};
      $.extend(
        viewData,
        ajaxView.settings,
        Drupal.Views.parseQueryString(href),
        // Extract argument data from the URL.
        Drupal.Views.parseViewArgs(href, ajaxView.settings.view_base_path)
      );

      var settings = $.extend({}, ajaxView.element_settings, {
        submit: viewData,
        base: false,
      });
      // Load AJAX element_settings object and attach AJAX behaviour.
      if (element) {
        settings.element = element;
      }
      if (event) {
        settings.event = event;
      }
      ajaxView.pagerAjax = Drupal.ajax(settings);
      return ajaxView.pagerAjax;
    },

    /**
     * Views - Check if element is part of a view preview form.
     *
     * @param {HTMLElement} element
     *   The element to associate the AJAX behaviour with.
     *
     * @return {number}
     *   The number of '#views-live-preview' elements found. If above 0, then
     *   we are in a view preview form context.
     */
    getViewsPreviewContext: function (element) {
      return $(element).parents('#views-live-preview').length;
    },

    /**
     * Views - Set Views preview AJAX.
     *
     * @param {HTMLElement} element
     *   The element to associate the AJAX behaviour with.
     * @param {event} event
     *   The event that will trigger the AJAX behaviour.
     * @param {string} path
     *   The URL to invoke.
     *
     * @return {Drupal.Ajax}
     *   A Drupal.Ajax object.
     */
    setAjaxViewPreviewPaging: function (element, event, path) {
      var element_settings = {
        url: path,
        event: event,
        progress: {type: 'fullscreen'},
        method: 'replaceWith',
        wrapper: 'views-preview-wrapper'
      };
      if (element) {
        element_settings.base = $(element).attr('id');
        element_settings.element = element;
      }
      if (event) {
        element_settings.event = event;
      }
      return Drupal.ajax(element_settings);
    }
  };

})(jQuery);
